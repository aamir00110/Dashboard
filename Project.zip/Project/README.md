# Stretchable Elastic Toggle - CSS

A Pen created on CodePen.

Original URL: [https://codepen.io/josetxu/pen/ExJXRBB](https://codepen.io/josetxu/pen/ExJXRBB).

